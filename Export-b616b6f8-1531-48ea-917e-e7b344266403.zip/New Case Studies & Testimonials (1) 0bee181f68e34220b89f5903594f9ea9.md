# New Case Studies & Testimonials (1)

We’ll use the project board below to ideate, plan, and project manage execution of new case studies and testimonials.

- Sources for content:
    - [Monday company meeting wins](https://docs.google.com/spreadsheets/d/1By55TcqcficUPOhFLBUFETvx3LcafRWVUzgP78-U_48/edit#gid=1464790744)
    - [Wall of social testimonials](https://www.figma.com/file/O8yWEvvRqntRsJdP6sjCue/Wall-of-Social-Recommendations?node-id=304%3A1294&t=bjTKODI55RJmdvpA-0)
    - Customer wins Slack channel
    - Our LinkedIn and Twitter social channels (FB not so much)

- Email template
    
    @Heather Osteen Can you please put an email template out here that you (and I) can use to make reaching out easier? For example:
    
    Hi __
    
    I’m ___
    
    I noticed your [tweet, LinkedIn post…] OR My colleague ___ at Elevar mentioned…
    
    Would you be open to having a conversation about ___
    
    I promise, I will do all the heavy lifting crafting the content and you’ll have full approval rights…
    
    Book 15-minutes on my calendar here [Calendly link]
    
    Subject: 	**Your Elevar Story**
    
    OR		**Case Study Conversation**
    
    OPTION #1: **General and Generic**
    
    Hi, Name,
    
    I understand you have some positive feedback about Elevar - and we love to hear that! As our content marketing manager in residence, I'd be grateful if we could schedule some time to talk for a few minutes (20 minutes!) about your Elevar story.
    
    You’d have full approval rights prior to publication (of course), and I would do all the work for us. Here’s my calendly link for easy scheduling.
    
    I look forward to speaking with you,
    
    Heather O.
    
    OPTION #2: **Twitter/LinkedIn/Other Specific Comment to reference**
    
    Hi, Name,
    
    Thank you so much for your kind words on Twitter about us! You started a great conversation, and we’re so glad you’re thrilled with Elevar.
    
    I’m in charge of content here, and I would love to hop on a call - 20 minutes or less - to hear your Elevar story.You’d have full approval rights prior to publication (of course), and I would do all the work for us. My calendly link is here for easy scheduling. 
    
    Again, thank you so much for publicly praising Elevar. It means a lot to us!
    
    Happy …day,
    
    Heather O.
    
    Signature
    

- Tools to explore:
    - [https://vouchfor.com](https://vouchfor.com/)

[Case Studies](https://www.notion.so/aa5bf4bafa904ca7a6b2a3b5bfea1f0a)

[Untitled](https://www.notion.so/1cab772d7c214fe29ca759349c7ff2d2)